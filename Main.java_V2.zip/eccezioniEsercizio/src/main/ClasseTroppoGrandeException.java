package main;

public class ClasseTroppoGrandeException extends Exception{
    public ClasseTroppoGrandeException(String s) {
        super(s);
    }
}
