package main;

public class Classe {
    private String studenti;
    private int maxStudenti = 3;

    public Classe(String studenti) throws ClasseTroppoGrandeException {
        if (contaStudenti(studenti) > maxStudenti) {
            throw new ClasseTroppoGrandeException("Classe troppo grande");
        } else {this.studenti = studenti;}
    }

    public int contaStudenti(String s) {
        int cont = 1;
        for(int i=0; i<s.length(); i++) {
            if(s.charAt(i) == ',') {
                cont++;
            }
        }
        return cont;
    }
}
