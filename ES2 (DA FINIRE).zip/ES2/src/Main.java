import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Inserisci il primo numero binario: ");
        String s1 = in.next();
        System.out.print("Inserisci il secondo numero binario: ");
        String s2 = in.next();

    }
    public static boolean check(String s, String s2) {
        boolean bool = false;
        
        return bool;
    }

    public static void swapsMinimi(String s, String s2) {

    }
}